package com.sih.esal.presentment.fee.jobs;

import com.sih.esal.presentment.fee.config.PresentmentFeeSchedulerConfig;
import com.sih.esal.presentment.fee.service.MonthlyPresentmentFeeService;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

@Component
@DisallowConcurrentExecution
public class MonthlyPresentmentInvoiceCreateBatch implements Job{
	
	Logger logger = LoggerFactory.getLogger(MonthlyPresentmentInvoiceCreateBatch.class);
	
	@Value("${cron.frequency.create.invoice}")
	private String frequency;
	@Autowired
	MonthlyPresentmentFeeService monthlyPresentmentFeeService;

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		logger.debug("start MonthlyPresentmentInvoiceCreateBatch ....");
		monthlyPresentmentFeeService.monthlyPresentmentFeeDetails();

		logger.debug("end MonthlyPresentmentInvoiceCreateBatch ....");
		
	}
	
	@Bean(name = "monthlyInvoiceCreate")
	public JobDetailFactoryBean createJob() {
		return PresentmentFeeSchedulerConfig.createJobDetail(this.getClass(),"monthlyInvoiceCreate");
	}	

	@Bean(name = "monthlyInvoiceCreateTrigger")
	public CronTriggerFactoryBean createJobTrigger(@Qualifier("monthlyInvoiceCreate") JobDetailFactoryBean searhcInvoiceBean) {
		return PresentmentFeeSchedulerConfig.createCronTrigger(searhcInvoiceBean.getObject(), frequency,"monthlyInvoiceCreateTrigger");
	}

}
                                                       