package com.sih.esal.presentment.fee;

import org.springframework.context.annotation.*;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;

@Configuration
@ImportResource(value = { "classpath:presentmentfee-core.xml" })
//@EnableAutoConfiguration(exclude= RabbitAutoConfiguration.class)
public class PresentmentFeeConfig  {

    @Primary
    @Bean(name = "feedatasource")
    @ConfigurationProperties(prefix = "presentmentfee.datasource")
    public DataSource coreDbdataSource() {
        return DataSourceBuilder.create().build();
    }

}
