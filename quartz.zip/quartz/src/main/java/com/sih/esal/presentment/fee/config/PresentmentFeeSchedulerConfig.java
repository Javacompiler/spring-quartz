package com.sih.esal.presentment.fee.config;

import org.quartz.JobDetail;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.spi.JobFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.quartz.QuartzProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

@Configuration
public class PresentmentFeeSchedulerConfig {

    Logger logger = LoggerFactory.getLogger(PresentmentFeeSchedulerConfig.class);

    @Autowired
    List<Trigger> listOfTrigger;


    @Autowired
    QuartzProperties quartzProperties;

    @Bean
    public JobFactory jobFactory(ApplicationContext applicationContext) {
       logger.debug("Getting a handle to the jobFactory");
        PresentmentFeeJobFactory jobFactory = new PresentmentFeeJobFactory();
        jobFactory.setApplicationContext(applicationContext);
        return jobFactory;
    }


    @Bean
    public SchedulerFactoryBean schedulerFactoryBean(DataSource dataSource, JobFactory jobFactory) throws IOException {
        logger.debug("Getting a handle to the schedulerFactoryBean");
        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        factory.setOverwriteExistingJobs(true);
        factory.setAutoStartup(true);
        factory.setDataSource(dataSource);
        factory.setJobFactory(jobFactory);
        factory.setQuartzProperties(quartzProperties());


        // Here we will set all the trigger beans we have defined. if
        if(!CollectionUtils.isEmpty(listOfTrigger)) {
            factory.setTriggers(listOfTrigger.toArray(new
                    Trigger[listOfTrigger.size()])); }

        return factory;
    }

    @Bean
    @ConfigurationProperties(prefix = "presentmentfee.quartz")
    public Properties quartzProperties() throws IOException {
        Properties properties = new Properties();
        properties.putAll(quartzProperties.getProperties());

        return properties;
    }


    // Use this method for creating cron triggers instead of simple triggers:
    public static CronTriggerFactoryBean createCronTrigger(JobDetail jobDetail, String cronExpression, String name) {

        CronTriggerFactoryBean factoryBean = new CronTriggerFactoryBean();
        factoryBean.setJobDetail(jobDetail);
        factoryBean.setName(name);
        factoryBean.setCronExpression(cronExpression);
        factoryBean.setMisfireInstruction(SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
        return factoryBean;
    }

    public static JobDetailFactoryBean createJobDetail(Class jobClass, String name) {
        JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
        factoryBean.setJobClass(jobClass);
        factoryBean.setName(name);
        factoryBean.setDurability(true);
        return factoryBean;
    }

}
