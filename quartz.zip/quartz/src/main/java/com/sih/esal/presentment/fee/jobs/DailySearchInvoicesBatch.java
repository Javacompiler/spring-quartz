package com.sih.esal.presentment.fee.jobs;

import com.sih.esal.presentment.fee.config.PresentmentFeeSchedulerConfig;
import com.sih.esal.presentment.fee.service.SearchInvoicePresentmentFeeService;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Component
@DisallowConcurrentExecution
public class DailySearchInvoicesBatch implements Job{
	
	Logger logger = LoggerFactory.getLogger(DailySearchInvoicesBatch.class);
	
	@Value("${cron.frequency.search.invoice}")
	private String frequency;

@Autowired
	SearchInvoicePresentmentFeeService presentmentFeeService;

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		   logger.debug("invoice job start ");
			presentmentFeeService.searchPresentmentFeeInvoice();
			logger.debug("invoice job end ");

	}
	
	@Bean(name = "dailySearchInvoicesJob")
	public JobDetailFactoryBean createJob() {
		return PresentmentFeeSchedulerConfig.createJobDetail(this.getClass(),"dailySearchInvoicesJob");
	}	

	@Bean(name = "dailySearchInvoicesTrigger")
	public CronTriggerFactoryBean createJobTrigger(@Qualifier("dailySearchInvoicesJob") JobDetailFactoryBean searhcInvoiceBean) {
		return PresentmentFeeSchedulerConfig.createCronTrigger(searhcInvoiceBean.getObject(), frequency,"dailySearchInvoicesTrigger");
	}

}
                                                       